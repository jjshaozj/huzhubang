package com.a8plus1.seen.Adapter;

import junit.framework.TestCase;

public class MessageRecyclerAdapterTest extends TestCase {

}